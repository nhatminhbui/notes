from PIL import Image, ImageFont, ImageDraw

img_path = 'sample.png'
text = ""
#text = text.upper()
sign = "NHAT&NHAT"
date = "05.14.21"

font = ImageFont.truetype('SpecialElite-Regular.ttf', 60)
sign_font = ImageFont.truetype('SpecialElite-Regular.ttf', 80)
# Output is saved as output.png


# =====================================================


size = 2000

margin = size//30
sample_text = text

final = Image.new('RGB', (size, size), (255, 255, 255))

bg = final.copy()
frame = Image.open('frame.png').convert('RGBA');
frame = frame.resize((size//2+size//40, size//2+size//40))
texture = Image.open('texture.png')
texture = texture.resize((size, size))
im = Image.open(img_path).convert('RGBA')
im = square_crop(im)

bg.paste(im, (size//4, size//4), mask=im) 
bg.paste(frame, (size//4, size//4), mask=frame)
bg.paste(texture, (0, 0), mask=texture)

temp = bg.copy()
write = ImageDraw.Draw(temp)

def square_crop(img):
    crop_size = size // 2 # Don't change the crop_size. I'm too lazy to calculate.
    def scale(img):
        w = im.size[0]
        h = im.size[1]
        if w < h:
            h = crop_size * h/w
            w = crop_size
        else:
            w = crop_size * w/h
            h = crop_size
        return img.resize((int(w), int(h)))
    img = scale(img)
    x, y = img.size[0]//2, img.size[1]//2
    half = crop_size // 2
    # left, top, right, bottom
    return img.crop((x-half, y-half, x+half, y+half))

def create_sign(name, date):
    date_x = size - margin - font.getsize(date)[0]
    date_y = size - margin - font.getsize(date)[1]
    sign_x = date_x - margin//2 - sign_font.getsize(name)[0]
    sign_y = size - margin - sign_font.getsize(name)[1]
    write.text((date_x, date_y), date, (0, 0, 0), font=font)
    write.text((sign_x, sign_y), name, (0, 0, 0), font=sign_font)
    
def get_em(font):
    w = font.getsize('M')
    h = w[1]
    w = w[0]
    return (w, h)

def get_spacesize(font):
    w = font.getsize(' ')
    h = w[1]
    w = w[0]
    return (w, h)

def write_sentence(sen, left_margin, right_margin, y):
    width = right_margin - left_margin
    actual_width = font.getsize(sen)[0]
    blank = width - actual_width
    spaces = sen.count(' ')
    if spaces == 0:
        add_per_space = get_spacesize(font)[0]
    else:
        add_per_space = get_spacesize(font)[0] + blank // spaces + 3
    sen = sen.split()
    for word in sen:
        write.text((left_margin, y), word, (32, 30, 30), font=font)
        left_margin += font.getsize(word)[0]+add_per_space


top_rows = (size//4-margin) // (get_em(font)[1]+30) + 1
top_cols = ((size-2*margin) // get_em(font)[0]) // 0.8 #Magic
bottom_rows = top_rows - 2
central_rows = top_rows * 2 + 2
side_cols = top_cols // 5 #Magic

damn = sample_text.split()
lines = 1
y = margin
temp_sen = ""

for word in damn:
    if y >= (size - margin - get_em(font)[1] - get_em(sign_font)[1]-30):
                break
    if lines <= top_rows:
        if len(temp_sen+word) <= top_cols:
            temp_sen += word + " "
        else:
            write_sentence(temp_sen, margin, size-margin, y)
            temp_sen = word + " "
            lines += 1
            y += get_em(font)[1] + 30
            
    elif lines <= top_rows + central_rows:
        if len(temp_sen+word) <= side_cols*2:
            temp_sen += word + " "
        else:
            x = (temp_sen.count(' ')+1) // 2
            half_left = ' '.join(temp_sen.split()[:x])
            half_right = ' '.join(temp_sen.split()[x:])
            write_sentence(half_left, margin, size//4, y)
            write_sentence(half_right, size-size//4+margin, size-margin, y)
            temp_sen = word + " "
            lines += 1
            y += get_em(font)[1] + 30
            
    else:
        if len(temp_sen+word) <= top_cols:
            temp_sen += word + " "
        else:
            write_sentence(temp_sen, margin, size-margin, y)
            temp_sen = word + " "
            lines += 1
            y += get_em(font)[1] + 30
            

create_sign(sign, date)
final.paste(temp, (0, 0))
final.save('output.png')
